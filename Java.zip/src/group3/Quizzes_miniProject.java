package group3;

import java.util.Scanner;

public class Quizzes_miniProject {
    public static void main(String[] args) {
        Scanner scanner1 = new Scanner(System.in);
        char repeat;

        do {
            System.out.println("\n\tWELCOME TO QUIZZES\n");
            System.out.println(" __Pls enter your Registration number__");


            System.out.println("Reg. Num:");
            String regNum = scanner1.nextLine();


            if (regNum.length() == 9 && regNum.charAt(1)=='2'&& regNum.charAt(2)=='3'&& (isNumeric(regNum)) ){
                //You can only enter a reg.no with 9 characters: 1st character=2 and 2nd character=3 ( Ex: X23XXXXXX  X should be [0-9] digit)

                System.out.println("\nPls select a subject");
                String[] subjects = {"DBMS", "SAD", "COMPUTER ORGANIZATION","PROGRAMMING","MATHEMATICS"};
                for (int i = 0; i < subjects.length; i++) {
                    System.out.println("(" + (i + 1) + ")" + subjects[i]);
                }

                System.out.println("Pls type here the number of the subject you choose:");
                int subNum = scanner1.nextInt();

                if (subNum >= 1 && subNum <= subjects.length ){
                    System.out.println("_______________________________________________");
                    System.out.println("       " + subjects[subNum - 1] + " QUIZZES" + "            ");
                    System.out.println("_______________________________________________\n");
                    System.out.println("\n** Answer the all questions **\n");

                    String[] questionsDBMS = {
                            "What does SQL stand for?\n",
                            "Which of the following is NOT a type of database model?\n",
                            "Which of the following is used to define the structure of a database?\n",
                            "Which command is used to retrieve data from a database?\n",
                            "Which of the following is used to join rows from two or more tables based on a related column between them?\n"
                    };

                    String[] questionsSAD = {
                            "What is the modern view on a system?\n",
                            "What does 'Interconnectivity Optimization' involve in the context of software systems?\n",
                            "What defines the computational prowess (ability) of a system?\n",
                            "How are control mechanisms characterized in modern systems?\n",
                            "Which of the following features characterizes an Adaptive System?\n"
                    };

                    String[] optionsDBMS = {
                            "A) Structured Question Language\nB) Structured Query Language\nC) Sequential Query Language\nD) Server Query Language",
                            "A) Hierarchical\nB) Network\nC) Relational\nD) Circular",
                            "A) DML\nB) DDL\nC) DCL\nD) TCL",
                            "A) SELECT\nB) INSERT\nC) UPDATE\nD) DELETE",
                            "A) GROUP BY\nB) ORDER BY\nC) INNER JOIN\nD) UNION"
                    };

                    String[] optionsSAD = {
                            "A) A random collection of components\nB) An isolated grouping of independent elements\nC) An organized grouping of interdependent components linked according to a plan\nD) A chaotic arrangement of unrelated parts",
                            "A) Isolating systems from external sources\nB) Encouraging redundancy in data sources\nC) Seamless integration with external systems, APIs, and data sources\nD) Limiting interactions with APIs for security reasons",
                            "A) The nature of processors\nB) Handling complex computations\nC) Data-intensive tasks\nD) All of the above",
                            "A) Rigid and rule-based\nB) Adaptive and intelligent\nC) Static decision-making processes\nD) Exclusion of smart algorithms",
                            "A) Emphasis on intentional stability\nB) Fixed and unchanging structures\nC) Incorporation of machine learning and AI\nD) Avoidance of predictability and control"
                    };

                    String[] questionsCO = {"What is the first arithmetic machine",
                            "What is the technology that used in 2nd generation",
                            "What are the 3 major classes of computer software",
                            "What does RAM stands for",
                            "Write one computer category based on size"};

                    String[] questionsPROGRAMMING = {
                            "What is the correct way to declare a Java array?\n",
                            "Which of the following is not a valid variable name in most programming languages?\n",
                            "Which of the following data types is used to store a sequence of characters?\n",
                            "What is the purpose of a conditional statement in programming?\n",
                            "What is the role of a variable in programming?\n"
                    };
                    String[] optionsPROGRAMMING = {
                            "A) int arr[];\nB) int[] arr;\nC) array arr[];\nD) array[] arr;",
                            "A) my_variable\nB) 123variable\nC) var123\nD) variable_123",
                            "A) int\nB) float\nC) string\nD) bool",
                            "A) To repeat a block of code a specific number of times\nB) To define a function or method\nC) To execute different blocks of code based on specified conditions\nD) To store a sequence of characters",
                            "A) To perform mathematical operations\nB) To store and manipulate data that can change during program execution\nC) To define the layout and design of a user interface\nD) To execute a sequence of statements repeatedly"
                    };

                    String[] questionsMaths = {
                            "What is the derivative of f(x) = 3x^2+2x+1 ?\n",
                            "What is the integral of ∫(4x^3 +3x^2)dx?\n",
                            "What is the circumference of a circle with radius 5 units?\n",
                            "In how many ways can 4 people be arranged in a line?\n",
                            "What is the limit of lim x→2 (x^2 −4)?\n"
                    };
                    String[] optionsMaths = {
                            "A) 6x+2\nB) 6x^2+2x\nC) 3x+2\nD) 6x+2x",
                            "A) x^4+x^3+C\nB) x^4+x^3+x+C\nC) x^4+x^2+C\nD)2x^4+3x^2+C ",
                            "A) 10π units\nB) 15π units\nC) 25π units\nD) 5π units",
                            "A) 24\nB) 12\nC) 6\nD) 4",
                            "A) 0\nB) 2\nC) 4\nD) 8"
                    };


                    char[] answersDBMS = {'B', 'D', 'B', 'A', 'C'};
                    char[] answersSAD = {'C', 'C', 'D', 'B', 'C'};
                    char[] answersProgramming = {'B', 'B', 'C', 'C','B'};
                    char[] answersMaths = {'A', 'A', 'A', 'A','C'};


                    int score = 0;

                    if (subNum == 1) {
                        for (int i = 0; i < questionsDBMS.length; i++) {
                            System.out.println("\nQ" + (i + 1) + ") " + questionsDBMS[i]);
                            System.out.println(optionsDBMS[i]);
                            System.out.print("Your answer (A/B/C/D): ");
                            char studentAnswerDBMS = scanner1.next().charAt(0);
                            if (Character.toUpperCase(studentAnswerDBMS) == answersDBMS[i]) {
                                System.out.println("Correct!\n");
                                score++;
                            } else {
                                System.out.println("Incorrect. The correct answer is " + answersDBMS[i] + "\n");
                            }

                        }
                    } else if (subNum == 2) {
                        for (int j = 0; j < questionsSAD.length; j++) {
                            System.out.println("\nQ" + (j + 1) + ") " + questionsSAD[j]);
                            System.out.println(optionsSAD[j]);
                            System.out.print("Your answer (A/B/C/D): ");
                            char studentAnswerSAD = scanner1.next().charAt(0);
                            if (Character.toUpperCase(studentAnswerSAD) == answersSAD[j]) {
                                System.out.println("Correct!\n");
                                score++;
                            } else {
                                System.out.println("Incorrect. The correct answer is " + answersSAD[j] + "\n");
                            }
                        }


                    } else if (subNum == 3) {
                        System.out.println("__Please Type the answer__ ");
                        scanner1.nextLine();

                        for (int i = 0; i < questionsCO.length; i++) {
                            System.out.println("\n(Q" + (i + 1) + ") " + questionsCO[i] + "?");
                            String answer = scanner1.nextLine().toLowerCase();

                            if (answer.contains("abacus")) {
                                System.out.println("Correct Answer!!");
                                score++;
                            } else if (answer.contains("transistor")) {
                                System.out.println("Correct Answer!");
                                score++;
                            } else if (answer.contains("system") && answer.contains("application") && answer.contains("programming")) {
                                System.out.println("Correct Answer!");
                                score++;
                            } else if (answer.contains("random access memory")) {
                                System.out.println("Correct Answer!");
                                score++;
                            } else if (answer.contains("micro") && answer.contains("computer") || answer.contains("mini") && answer.contains("computer") || answer.contains("mainframe") || answer.contains("super") && answer.contains("computer")) {
                                System.out.println("Correct Answer!");
                                score++;
                            } else {
                                System.out.println("Incorrect Answer");
                            }
                        }
                    } else if (subNum==4) {
                        for (int j = 0; j < questionsPROGRAMMING.length; j++) {
                            System.out.println("\nQ" + (j + 1) + ") " + questionsPROGRAMMING[j]);
                            System.out.println(optionsPROGRAMMING[j]);
                            System.out.print("Your answer (A/B/C/D): ");
                            char studentAnswerProgramming = scanner1.next().charAt(0);
                            if (Character.toUpperCase(studentAnswerProgramming) == answersProgramming[j]) {
                                System.out.println("Correct!\n");
                                score++;
                            } else {
                                System.out.println("Incorrect. The correct answer is " + answersProgramming[j] + "\n");
                            }
                        }
                    } else if (subNum==5) {

                        for (int j = 0; j < questionsMaths.length; j++) {
                            System.out.println("\nQ" + (j + 1) + ") " + questionsMaths[j]);
                            System.out.println(optionsMaths[j]);
                            System.out.print("Your answer (A/B/C/D): ");
                            char studentAnswerMaths = scanner1.next().charAt(0);
                            if (Character.toUpperCase(studentAnswerMaths) == answersMaths[j]) {
                                System.out.println("Correct!\n");
                                score++;
                            } else {
                                System.out.println("Incorrect. The correct answer is " + answersMaths[j] + "\n");
                            }
                        }


                    } else {
                        System.out.println("Invalid input for subject.");
                    }

                    System.out.println("\nQuiz completed!");
                    System.out.println("Your score: " + score + "/" + (questionsSAD.length));
                } else {
                    System.out.println("Invalid subject number.");
                }
            } else {
                System.out.println("Your Reg.No is incorrect or You have not registered to this course ");
            }


            System.out.println("\nTo go to main menu -type 'Y' and \nTo exit the process -type 'N'   (Y/N): ");
            repeat = scanner1.next().charAt(0);
            scanner1.nextLine(); // to type yes or no option

        } while (Character.toUpperCase(repeat) == 'Y');

        if (Character.toUpperCase(repeat) == 'N') {
            System.out.println("\n\tTHANK YOU!!!");
        } else {
            System.out.println("INVALID...");
        }

        scanner1.close();
    }

    public static boolean isNumeric(String regNum) {

        return regNum.matches("\\d+"); // any digits between [0-9]
    }
}

